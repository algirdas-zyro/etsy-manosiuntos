(function () {
	'use strict';

	const importPath = /*@__PURE__*/JSON.parse('"../content/manosiuntos.js"');

	import(importPath);

}());
