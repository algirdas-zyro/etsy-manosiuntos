console.log("background script working");
